package com.tweetapp.socialmedia.tweet.service;

import java.util.Scanner;

import com.tweetapp.socialmedia.tweet.connection.Helper;
import com.tweetapp.socialmedia.tweet.dao.UserDao;
import com.tweetapp.socialmedia.tweet.dao.UserTweetDao;
import com.tweetapp.socialmedia.tweet.model.User;
import com.tweetapp.socialmedia.tweet.model.UserTweet;

public class UserTweetService {
	UserTweetDao userTweetDao = new UserTweetDao();
	UserDao userDao = new UserDao();
	Helper helper = new Helper();

	Scanner sc = new Scanner(System.in);

	public void loggedUser(User user) {
		UserTweet userTweet = new UserTweet();
		userTweet.setEmailid(user.getEmailid());
		boolean userActive = true;
		while (userActive) {
			System.out.println("WELCOME TO TWEET APP");
			System.out.println("Enter 1 for Post a Tweet");
			System.out.println("Enter 2 for View my Tweet");
			System.out.println("Enter 3 for View all Tweet");
			System.out.println("Enter 4 for View all Users");
			System.out.println("Enter 5 for Reset Passsword");
			System.out.println("Enter 6 for Logout");
			int choice;
			choice = Integer.parseInt(sc.nextLine());
			switch (choice) {
			case 1:
				System.out.println("Enter Your Tweet");
				String tweet = sc.nextLine();
				int sucess = userTweetDao.posttweet(user.getEmailid(), tweet);
				if (sucess != 0)
					System.out.println("Tweet posted sucessfully");
				else
					System.out.println("Posting Tweet unsucesfull");
				break;
			case 2:
				userTweetDao.viewUserTweets(user.getEmailid());
				break;
			case 3:
				userTweetDao.viewAllTweets();
				break;
			case 4:
				userDao.viewAllUser();
				break;
			case 5:
				String password = "Enter new Your Password";
				while (true) {
					System.out.println(
							"NOTE - Password must be 8-20 charactes,atleast with one digits,one lowercase and one uppercase \n"
									+ password);
					String newPassWord = sc.nextLine();
					if (helper.validPassword(newPassWord) == true) {
						int resetPassword = userTweetDao.resetPassword(user.getEmailid(), newPassWord);
						if (resetPassword != 0)
							System.out.println("Password has been reset sucessfully");
						else
							System.out.println("Password reset unsuccessfull");
						break;
					} else {
						password = "Password Invalid Please Re-enter Your  new Password";
					}
				}
				break;
			case 6:
				userDao.logout(user.getEmailid());
				userActive = false;
				break;

			}
		}
	}

}
