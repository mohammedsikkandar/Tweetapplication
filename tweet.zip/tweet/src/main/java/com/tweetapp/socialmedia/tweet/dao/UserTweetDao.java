package com.tweetapp.socialmedia.tweet.dao;

import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.tweetapp.socialmedia.tweet.connection.ConnectionHandler;

public class UserTweetDao extends UserDao {
	private final static String insertTweetquery = "insert into UserTweet values(?,?,?)";
	private final static String viewUserTweetquery = "select * from UserTweet where Emailid=?";
	private final static String viewAllTweets = "select * from UserTweet";

	public int posttweet(String emailId, String tweet) {
		int sucess = 0;
		LocalDateTime date = LocalDateTime.now();
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
		String formatedDate = date.format(format);
		try {
			con = ConnectionHandler.getConnection();
			ps = con.prepareStatement(insertTweetquery);
			ps.setString(1, emailId);
			ps.setString(2, tweet);
			ps.setString(3, formatedDate);
			sucess = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sucess;
	}

	public void viewUserTweets(String emailid) {
		try {
			con = ConnectionHandler.getConnection();
			ps = con.prepareStatement(viewUserTweetquery);
			ps.setString(1, emailid);
			ResultSet rs = ps.executeQuery();
			System.out.println("Your Tweets");
			while (rs.next()) {
				System.out.println(rs.getString(1) + " posted:\n " + rs.getString(2) + " at " + rs.getString(3));
			}
		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	public void viewAllTweets() {
		try {
			con = ConnectionHandler.getConnection();
			ps = con.prepareStatement(viewAllTweets);
			ResultSet rs = ps.executeQuery();
			rs = ps.executeQuery();
			while (rs.next()) {
				System.out.println(rs.getString(1) + " posted:\n " + rs.getString(2) + " at " + rs.getString(3));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public int resetPassword(String emailid, String password) {
		int sucess = 0;
		try {
			con = ConnectionHandler.getConnection();
			ps = con.prepareStatement(updatePasswordquery);
			ps.setString(1, password);
			ps.setString(2, emailid);
			sucess = ps.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sucess;

	}

}
