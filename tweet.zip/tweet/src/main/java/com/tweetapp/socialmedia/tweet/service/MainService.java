package com.tweetapp.socialmedia.tweet.service;

import java.util.Scanner;

public class MainService {
	UserService userservice = new UserService();
	Scanner sc = new Scanner(System.in);
	int choice;

	public void main() {
		while (true) {
			System.out.println("WELCOME TO TWEET APP");
			System.out.println("Select your option");
			System.out.println("Enter 1 for Register");
			System.out.println("Enter 2 for Login");
			System.out.println("Enter 3 for Forgot Password");

			choice = sc.nextInt();

			switch (choice) {
			case 1:
				userservice.register();
				break;
			case 2:
				userservice.login();
				break;
			case 3:
				userservice.forgotPassword();
				break;
			}
		}

	}

}
