package com.tweetapp.socialmedia.tweet.connection;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class ConnectionHandler {

	public static Connection getConnection() throws IOException, ClassNotFoundException, SQLException {

		Properties property = new Properties();
		Connection connection;
		String fileName = "src/main/java/db.properties";
		FileInputStream f = new FileInputStream(fileName);
		property.load(f);
		String driver = (String) property.get("driver");
		Class.forName(driver);
		String url = (String) property.get("connection-url");
		String user = (String) property.get("user");
		String password = (String) property.get("password");
		connection = DriverManager.getConnection(url, user, password);
		return connection;
	}

}
