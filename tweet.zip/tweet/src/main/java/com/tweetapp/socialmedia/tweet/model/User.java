package com.tweetapp.socialmedia.tweet.model;

public class User {
	private int Userid;
	private String LastName;
	private String FirstName;
	private String Gender;
	private String Emailid;
	private String Password;
	private String DOB;
	private String Status;

	public User() {
		super();
	}

	public User(int userid, String lastName, String firstName, String gender, String emailid, String password,
			String dOB, String status) {
		super();
		Userid = userid;
		LastName = lastName;
		FirstName = firstName;
		Gender = gender;
		Emailid = emailid;
		Password = password;
		DOB = dOB;
		Status = status;
	}

	public int getUserid() {
		return Userid;
	}

	public void setUserid(int userid) {
		Userid = userid;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public String getEmailid() {
		return Emailid;
	}

	public void setEmailid(String emailid) {
		Emailid = emailid;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public String getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) {
		DOB = dOB;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

}
