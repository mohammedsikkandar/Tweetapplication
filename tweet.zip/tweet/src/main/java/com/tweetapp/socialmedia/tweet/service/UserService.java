package com.tweetapp.socialmedia.tweet.service;

import java.util.Scanner;

import com.tweetapp.socialmedia.tweet.connection.Helper;
import com.tweetapp.socialmedia.tweet.dao.UserDao;
import com.tweetapp.socialmedia.tweet.model.User;

public class UserService {
	UserTweetService userTweetService = new UserTweetService();
	Helper helper = new Helper();
	Scanner sc = new Scanner(System.in);
	UserDao userDao = new UserDao();

	public void register() {
		User user = new User();
		System.out.println("WELCOME TO TWEET APP REGISTRATION");
		System.out.println("PLEASE ENTER THE FOLLOWING DETAILS");
		System.out.println("Enter Your LastName");
		user.setLastName(sc.nextLine());
		System.out.println("Enter Your FirstName");
		user.setFirstName(sc.nextLine());
		System.out.println("Enter Your Gender(M/F)");
		user.setGender(sc.nextLine());
		String email = "Enter Your Emailid";
		while (true) {
			System.out.println(email);
			String emailId = sc.nextLine();
			if (helper.validEmail(emailId) == true) {
				user.setEmailid(emailId);
				break;
			} else {
				email = "Emailid Invalid Please Re-enter Yout Emailid";
			}
		}
		String password = "Enter Your Password";
		while (true) {
			System.out.println(
					"NOTE - Password must be 8-20 charactes,atleast with one digits,one lowercase and one uppercase \n"
							+ password);
			String passWord = sc.nextLine();
			if (helper.validPassword(passWord) == true) {
				user.setPassword(passWord);
				break;
			} else {
				password = "Password Invalid Please Re-enter Your Password";
			}
		}
		String DateOfBirth = "Enter Your DOB (DD/MM/YYYY)";
		while (true) {
			System.out.println(DateOfBirth);
			String DOB = sc.nextLine();
			if (helper.validDob(DOB) == true) {
				user.setDOB(DOB);
				break;
			} else {
				DateOfBirth = "DateOfBirth Invalid Please Re-enter Your DateOfBirth (DD/MM/YYYY)";
			}
		}

		user.setStatus("Active");
		int result = userDao.userRegister(user);
		if (result != 0) {
			System.out.println("Registration Sucessfull!");
			userTweetService.loggedUser(user);
		} else {
			System.out.println("Registration UnSucessfull!");
			register();
		}
	}

	public void login() {
		System.out.println("WELCOME TO TWEET APP LOGIN");
		System.out.println("Enter your EmailId");
		String emailID = sc.nextLine();
		System.out.println("Enter your Password");
		String password = sc.nextLine();
		boolean login = userDao.login(emailID, password);
		if (login) {
			User user = new User();
			user.setEmailid(emailID);
			user.setPassword(password);
			userTweetService.loggedUser(user);
		} else {
			System.out.println("Invalid Credentials");
			login();
		}

	}

	public void forgotPassword() {
		System.out.println("Enter your EmailId");
		String emailID = sc.nextLine();
		System.out.println("Enter your DOB");
		String DOB = sc.nextLine();
		String password = "Enter Your new Password";
		while (true) {
			System.out.println(
					"NOTE - Password must be 8-20 charactes,atleast with one digits,one lowercase and one uppercase \n"
							+ password);
			String newPassWord = sc.nextLine();
			if (helper.validPassword(newPassWord) == true) {
				boolean sucess = userDao.forgotPassword(emailID, newPassWord, DOB);
				if (sucess == true)
					System.out.println("Password recovery sucessfully");
				else
					System.out.println("Password recovery failed");
				break;
			} else {
				password = "Password Invalid Please Re-enter Your  new Password";
			}
		}
	}

}
