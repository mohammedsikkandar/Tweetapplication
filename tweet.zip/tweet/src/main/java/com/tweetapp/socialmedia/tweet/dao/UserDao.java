package com.tweetapp.socialmedia.tweet.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.tweetapp.socialmedia.tweet.connection.ConnectionHandler;
import com.tweetapp.socialmedia.tweet.model.User;

public class UserDao {

	public Connection con = null;
	public PreparedStatement ps = null;
	private final static String RegisterUser = "insert into user(LastName,FirstName,Gender,Emailid,Password,DOB,Status) values(?,?,?,?,?,?,?)";
	private final static String LoginUser = "select * from user where Emailid=?";
	private final static String updatequery = "update user set Status=? where Emailid=?";
	private final static String viewAllUserQuery = "select * from user";
	private final static String getUserquery = "select * from user where Emailid=?";
	public final static String updatePasswordquery = "update user set Password=?  where Emailid=?";

	public int userRegister(User user) {
		int result = 0;
		try {
			con = ConnectionHandler.getConnection();
			ps = con.prepareStatement(RegisterUser);

			ps.setString(1, user.getLastName());
			ps.setString(2, user.getFirstName());
			ps.setString(3, user.getGender());
			ps.setString(4, user.getEmailid());
			ps.setString(5, user.getPassword());
			ps.setString(6, user.getDOB());
			ps.setString(7, user.getStatus());
			result = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public boolean login(String emailID, String password) {
		boolean login = false;
		try {
			con = ConnectionHandler.getConnection();
			ps = con.prepareStatement(LoginUser);
			ps.setString(1, emailID);
			ResultSet rs = ps.executeQuery();
			rs.next();

			if (rs.getString(6).equalsIgnoreCase(password)) {
				System.out.println("Sucessfully logged in!");
				ps = con.prepareStatement(updatequery);
				ps.setString(1, "Active");
				ps.setString(2, emailID);
				ps.executeUpdate();
				login = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return login;

	}

	public void logout(String emailid) {
		try {
			con = ConnectionHandler.getConnection();
			ps = con.prepareStatement(updatequery);
			ps.setString(1, "InActive");
			ps.setString(2, emailid);
			ps.executeUpdate();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}

	public void viewAllUser() {
		try {
			con = ConnectionHandler.getConnection();
			ps = con.prepareStatement(viewAllUserQuery);
			ResultSet rs = ps.executeQuery();
			rs = ps.executeQuery();
			while (rs.next()) {
				System.out.println(rs.getString(1) + "  " + rs.getString(2));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public boolean forgotPassword(String emailID, String newPassword, String dOB) {
		boolean sucess = false;
		try {
			con = ConnectionHandler.getConnection();
			ps = con.prepareStatement(getUserquery);
			ps.setString(1, emailID);
			ResultSet rs = ps.executeQuery();
			rs.next();
			if (rs != null) {
				if (rs.getString(7).equals(dOB)) {
					ps = con.prepareStatement(updatePasswordquery);
					ps.setString(1, newPassword);
					ps.setString(2, emailID);
					ps.executeUpdate();
					sucess = true;
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sucess;

	}

}
