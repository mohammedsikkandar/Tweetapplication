package com.tweetapp.socialmedia.tweet;

import com.tweetapp.socialmedia.tweet.service.MainService;

public class App {
	static MainService mainservice = new MainService();

	public static void main(String[] args) {
		mainservice.main();
	}
}
