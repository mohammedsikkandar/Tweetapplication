package com.tweetapp.socialmedia.tweet.model;

public class UserTweet {
	private String Emailid;
	private String Tweeet;
	private String Date;

	public UserTweet() {
		super();
	}

	public String getEmailid() {
		return Emailid;
	}

	public void setEmailid(String emailid) {
		Emailid = emailid;
	}

	public String getTweeet() {
		return Tweeet;
	}

	public void setTweeet(String tweeet) {
		Tweeet = tweeet;
	}

	public String getDate() {
		return Date;
	}

	public void setDate(String date) {
		Date = date;
	}

}
