package com.tweetapp.socialmedia.tweet.connection;

import java.util.regex.Pattern;

public class Helper {

	public boolean validPassword(String Password) {
		String passRegex = "^(?=.*[0-9])" + "(?=.*[a-z])(?=.*[A-Z])" + "(?=.*[@#$%^&+=])" + "(?=\\S+$).{8,20}$";
		Pattern pat = Pattern.compile(passRegex);
		if (Password == null) {
			return false;
		}
		return pat.matcher(Password).matches();

	}

	public boolean validEmail(String email) {
		String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\." + "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-z"
				+ "A-Z]{2,7}$";

		Pattern pat = Pattern.compile(emailRegex);
		if (email == null && email.equalsIgnoreCase("")) {
			return false;
		}
		return pat.matcher(email).matches();

	}

	public boolean validDob(String dob) {
		String dobRegex = "^[0-3]?[0-9]/[0-3]?[0-9]/(?:[0-9]{2})?[0-9]{2}$";
		Pattern pat = Pattern.compile(dobRegex);
		if (dob == null) {
			return false;
		}
		return pat.matcher(dob).matches();
	}

}
